﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace CatsDinner.Views
{
    public partial class StatusBar : ContentView
    {
        public StatusBar()
        {
            InitializeComponent();
        }
    }
}

