﻿using Xamarin.Forms;

namespace MusicSearch
{
    public partial class ResultsPage : ContentPage
    {
        public ResultsPage()
        {
            InitializeComponent();
        }
    }
}

