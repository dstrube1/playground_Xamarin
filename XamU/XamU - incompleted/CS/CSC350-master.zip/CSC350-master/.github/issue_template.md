<!--
Thank you so much for your contribution. Before you submit an issue, please read the following:

1. Ensure you have read over contribution guidelines in the README: https://github.com/XamarinUniversity/CSC350/blob/master/README.md.

2. If you have a question, please submit it via the Xamarin University forum: https://forums.xamarin.com/categories/university

3. Delete everything in this comment block.
-->

## What are you seeing?

## What is expected?

## What steps did you take to see this?

## Have any logged output/error messages that might help?

## About your system

### What operating system are you using? Windows? macOS?

### What version of Visual Studio are you using?
